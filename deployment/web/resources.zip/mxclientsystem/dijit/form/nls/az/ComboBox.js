//>>built
define("dijit/form/nls/az/ComboBox",{previousMessage:"\u018fvv\u0259lki variantlar",nextMessage:"Ba\u015fqa variantlar"});
