//>>built
define("dijit/nls/sr/common",{buttonOk:"U redu",buttonCancel:"Otka\u017ei",buttonSave:"Sa\u010duvaj",itemClose:"Zatvori"});
