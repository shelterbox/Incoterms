//>>built
define("dijit/form/nls/fr/ComboBox",{previousMessage:"Choix pr\u00e9c\u00e9dents",nextMessage:"Plus de choix"});
