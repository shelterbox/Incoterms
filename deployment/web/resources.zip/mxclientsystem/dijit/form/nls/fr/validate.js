//>>built
define("dijit/form/nls/fr/validate",{invalidMessage:"La valeur indiqu\u00e9e n'est pas correcte.",missingMessage:"Cette valeur est requise.",rangeMessage:"Cette valeur n'est pas comprise dans la plage autoris\u00e9e."});
