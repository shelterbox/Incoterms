//>>built
define("dijit/form/ComboBox",["dojo/_base/declare","./ValidationTextBox","./ComboBoxMixin"],function(a,b,c){return a("dijit.form.ComboBox",[b,c],{})});
