//>>built
define("dijit/_base/window",["dojo/window","../main"],function(b,a){a.getDocumentWindow=function(a){return b.get(a)}});
