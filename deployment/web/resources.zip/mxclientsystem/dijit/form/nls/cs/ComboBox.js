//>>built
define("dijit/form/nls/cs/ComboBox",{previousMessage:"P\u0159edchoz\u00ed volby",nextMessage:"Dal\u0161\u00ed volby"});
