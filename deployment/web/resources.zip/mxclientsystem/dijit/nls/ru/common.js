//>>built
define("dijit/nls/ru/common",{buttonOk:"OK",buttonCancel:"\u041e\u0442\u043c\u0435\u043d\u0430",buttonSave:"\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c",itemClose:"\u0417\u0430\u043a\u0440\u044b\u0442\u044c"});
