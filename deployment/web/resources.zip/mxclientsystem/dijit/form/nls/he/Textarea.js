//>>built
define("dijit/form/nls/he/Textarea",{iframeEditTitle:"\u05d0\u05d6\u05d5\u05e8 \u05e2\u05e8\u05d9\u05db\u05d4",iframeFocusTitle:"\u05de\u05e1\u05d2\u05e8\u05ea \u05d0\u05d6\u05d5\u05e8 \u05e2\u05e8\u05d9\u05db\u05d4"});
