//>>built
define("dijit/form/nls/ko/ComboBox",{previousMessage:"\uc774\uc804 \uc120\ud0dd\uc0ac\ud56d",nextMessage:"\uae30\ud0c0 \uc120\ud0dd\uc0ac\ud56d"});
